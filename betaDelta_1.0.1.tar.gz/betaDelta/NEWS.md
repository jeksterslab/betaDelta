# betaDelta 1.0.1

* Added the `DiffBetaDelta()` function.

# betaDelta 1.0.0

## Major

* And so it begins.
