#' @param x Named list of custom options.
#'   See https://yihui.org/knitr/options/ for more details.
KnitrOptionsCustom <- function(x = list()) {
  return(x)
}
