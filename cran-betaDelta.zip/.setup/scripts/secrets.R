#' Add environment tokens here.
#'
#' tokens <- c(
#'   KEY1 = "VALUE1",
#'   KEY2 = "VALUE2"
#' )
#'
if (git_user == "ijapesigan") {
  tokens <- c(
    GITHUB_PAT = "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", # nolint
    DOCKER_HUB_ACCESS_TOKEN = "dckr_pat_wQmel06PvE3-J8RtdScpxT4Rf3w", # nolint
    QUARTO_PUB_AUTH_TOKEN = "qpa_sjzwNHUxgaWEGpItfNDBUQO4QoDkDfYZraY2gsscYsFyRRC2occs08qkCp63jn5J", # nolint
    CODECOV_TOKEN = "0e286fe6-f9cb-4d5c-9e25-80213e6dd66d" # nolint
  )
}
if (git_user == "jeksterslab") {
  tokens <- c(
    GITHUB_PAT = "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", # nolint
    DOCKER_HUB_ACCESS_TOKEN = "dckr_pat_BmcA-weuhNfkxYzYvStQLxDEnpg", # nolint
    QUARTO_PUB_AUTH_TOKEN = "qpa_U2uxmVAWMsrYMustxoyvT86JvIDBmvEaVNrraVijqugBrgFkjhc8MKokCh9jTXpd", # nolint
    CODECOV_TOKEN = "4ebf6f30-d56d-4615-883a-15cf7c2bc2cd" # nolint
  )
}
if (git_user == "sigmaresearch100") {
  tokens <- c(
    GITHUB_PAT = "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", # nolint
    DOCKER_HUB_ACCESS_TOKEN = "dckr_pat_bB5EXVZ5BtEbMyNcTv6JE5HSrOA", # nolint
    QUARTO_PUB_AUTH_TOKEN = "qpa_QZ9gZk5VEWxl5hEo0Kps5dF6OehxPmlCtFohldJyCusHwX1PT9blYu8atMHWo4JW", # nolint
    CODECOV_TOKEN = "c3656a9c-2f77-421e-aae4-cb7a248932d4" # nolint
  )
}
if (git_user == "jeksterslab-psu") {
  tokens <- c(
    GITHUB_PAT = "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", # nolint
    DOCKER_HUB_ACCESS_TOKEN = "", # nolint
    QUARTO_PUB_AUTH_TOKEN = "", # nolint
    CODECOV_TOKEN = "" # nolint
  )
}
# CI_ijapesigan=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
# CI_jeksterslab=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
# CI_jeksterslab-psu=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
# CI_sigmaresearch100=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
