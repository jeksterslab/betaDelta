BetaDeltaMI <- function(object,
                        type = "mvn",
                        adj = FALSE,
                        ...) {
  stopifnot(
    type %in% c(
      "mvn",
      "adf"
    )
  )
  call0 <- stats::getCall(object)
  call1 <- call0
  for (i in 2:length(call0)) {
    call1[[i]] <- eval(
      expr = call0[[i]],
      envir = parent.frame()
    )
  }
  data0 <- eval(
    expr = call0[[i]],
    envir = parent.frame()
  )
  mi <- mice::complete(
    data = mice::mice(
      data = data0,
      print = FALSE,
      ...
    ),
    action = "all"
  )
  unstd_mi <- lapply(
    X = mi,
    FUN = function(x) {
      call1$data <- x
      return(
        eval(expr = call1)
      )
    }
  )
  lm_process_mi <- lapply(
    X = unstd_mi,
    FUN = .ProcessLM
  )
  std_mi <- lapply(
    X = lm_process_mi,
    FUN = .BetaDelta,
    type = type
  )
  coefs <- lapply(
    X = std_mi,
    FUN = function(x) {
      return(x$est)
    }
  )
  vcovs <- lapply(
    X = std_mi,
    FUN = function(x) {
      return(x$vcov)
    }
  )
  combined <- .MICombine(
    coefs = coefs,
    vcovs = vcovs,
    M = length(coefs),
    k = length(coefs[[1]]),
    adj = adj
  )
  est <- combined$est
  if (adj) {
    vcov <- combined$total_adj
  } else {
    vcov <- combined$total
  }
  args <- list(
    object = object,
    type = type,
    adj = adj
  )
  dots <- list(...)
  args <- c(
    args,
    dots
  )
  out <- list(
    call = match.call(),
    args = args,
    mi = mi,
    unstd = unstd_mi,
    lm_process = lm_process_mi,
    std = std_mi,
    vcov = vcov,
    est = est
  )
  attributes(out)$mi <- TRUE
  class(out) <- c(
    "betadelta",
    class(out)
  )
  return(
    out
  )
}
