#' @rdname rsq
#' @method rsq betadelta 
#' @export
rsq.betadelta <- function(object,
                          ...) {
  varnames <- c("R-squared", "Adjusted")
  est <- .RSqRSqBarofVechSigma(
    vechsigmacap = object$lm_process$vechsigmacap,
    k = object$lm_process$k,
    n = object$lm_process$n
  )
  names(est) <- varnames
  acov <- .ACov(
    jcap = .JacobianRSqRSqBarWRTVechSigma(
      x = object$lm_process$vechsigmacap,
      k = object$lm_process$k,
      n = object$lm_process$n
    ),
    gammacap = object$gamma
  )
  colnames(acov) <- rownames(acov) <- varnames
  vcov <- (1 / object$lm_process$n) * acov
  out <- list(
    betadelta = object,
    est = est,
    vcov = vcov,
    acov = acov
  )
  class(out) <- c(
    "rsqbetadelta",
    class(out)
  )
  return(
    out
  )
}
