# betaDelta 1.0.0.9000

Latest development version.

# betaDelta 1.0.0

## Major

* And so it begins.
