# betaDelta 1.0.0.9000

Latest development version.

* Added the `DiffBetaDelta()` function.

# betaDelta 1.0.0

## Major

* And so it begins.
