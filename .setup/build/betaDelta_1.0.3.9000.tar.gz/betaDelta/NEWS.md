# betaDelta 1.0.3.9000

* Latest development version.
* Added the `DeltaGeneric()` function.

# betaDelta 1.0.3

## Patch

* Minor documentation edits.

# betaDelta 1.0.2

## Patch

* Added degrees of freedom to the table of results.

# betaDelta 1.0.1

## Patch

* Added the `DiffBetaDelta()` function.

# betaDelta 1.0.0

## Major

* And so it begins.
