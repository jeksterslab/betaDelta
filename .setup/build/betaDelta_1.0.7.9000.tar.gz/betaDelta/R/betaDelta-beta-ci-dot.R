#' Confidence Intervals for
#' Standardized Regression Coefficients
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return Returns a matrix of
#'   standardized regression slopes,
#'   standard errors,
#'   test statistics,
#'   p-values,
#'   and
#'   confidence intervals.
#'
#' @param object Object of class `betadelta`.
#' @param alpha Numeric vector.
#'   Significance level \eqn{\alpha}.
#'
#' @family Beta Delta Functions
#' @keywords betaDelta ci internal
#' @noRd
.BetaCI <- function(object,
                    alpha = NULL) {
  if (is.null(x = alpha)) {
    alpha <- object$args$alpha
  }
  stopifnot(
    all(alpha > 0 & alpha < 1)
  )
  .CIWald(
    est = object$est,
    se = sqrt(x = diag(x = object$vcov)),
    theta = 0,
    alpha = alpha,
    z = FALSE,
    df = object$lm_process$df
  )
}
