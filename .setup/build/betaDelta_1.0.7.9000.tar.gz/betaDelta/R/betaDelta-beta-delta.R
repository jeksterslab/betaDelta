#' Estimate Standardized Regression Coefficients
#' and the Corresponding Sampling Covariance Matrix
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return Returns an object
#'   of class `betadelta` which is a list with the following elements:
#'   \describe{
#'     \item{call}{Function call.}
#'     \item{args}{Function arguments.}
#'     \item{lm_process}{Processed `lm` object.}
#'     \item{gamma}{Asymptotic covariance matrix
#'       of the sample covariance matrix.}
#'     \item{acov}{Asymptotic covariance matrix
#'       of the standardized slopes.}
#'     \item{vcov}{Sampling covariance matrix
#'       of the standardized slopes.}
#'     \item{est}{Vector of standardized slopes.}
#'   }
#'
#' @param object Object of class `lm`.
#' @param type Character string.
#'   If `type = "mvn"`,
#'   use the multivariate normal-theory approach.
#'   If `type = "adf"`,
#'   use the asymptotic distribution-free approach.
#' @param std_y Logical.
#'   Standardize \eqn{y}.
#'   With `std_y = FALSE`, \eqn{y} is left in its original units
#'   (\eqn{b_j \sigma_{x_j}}).
#' @param std_x Character vector or `NULL`.
#'   Names of the regressors to standardize.
#'   `NULL` (default) standardizes all regressors;
#'   `character(0)` standardizes none (\eqn{b_j / \sigma_y}).
#'   Leaving a dummy variable out keeps its 0-1 contrast.
#'   The delta method accounts for the sampling variability
#'   of the standard deviations.
#' @param alpha Numeric vector.
#'   Significance level \eqn{\alpha}.
#'
#' @references
#' Jones, J. A., & Waller, N. G. (2015).
#' The normal-theory and asymptotic distribution-free (ADF) covariance matrix
#' of standardized regression coefficients:
#' Theoretical extensions and finite sample behavior.
#' *Psychometrika*, *80*(2), 365--378.
#' \doi{10.1007/s11336-013-9380-y}
#'
#' Pesigan, I. J. A., Sun, R. W., & Cheung, S. F. (2023).
#' betaDelta and betaSandwich:
#' Confidence intervals for standardized regression coefficients in R.
#' *Multivariate Behavioral Research*.
#' \doi{10.1080/00273171.2023.2201277}
#'
#' Yuan, K.-H., & Chan, W. (2011).
#' Biases and standard errors of standardized regression coefficients.
#' *Psychometrika*, *76*(4), 670--690.
#' \doi{10.1007/s11336-011-9224-6}
#'
#' @examples
#' object <- lm(QUALITY ~ NARTIC + PCTGRT + PCTSUPP, data = nas1982)
#' std <- BetaDelta(object)
#' # Methods -------------------------------------------------------
#' print(std)
#' summary(std)
#' coef(std)
#' vcov(std)
#' confint(std, level = 0.95)
#'
#' @family Beta Delta Functions
#' @keywords betaDelta std
#' @export
BetaDelta <- function(object,
                      type = "mvn",
                      alpha = c(0.05, 0.01, 0.001),
                      std_y = TRUE,
                      std_x = NULL) {
  stopifnot(
    inherits(
      x = object,
      what = "lm"
    )
  )
  stopifnot(
    type %in% c(
      "mvn",
      "adf"
    )
  )
  lm_process <- .ProcessLM(object = object)
  index <- .BetaStarSelectIndex(
    std_x = std_x,
    xnames = lm_process$xnames
  )
  std <- .BetaDelta(
    lm_process = lm_process,
    type = type,
    std_y = std_y,
    std_x = index
  )
  out <- list(
    call = match.call(),
    args = list(
      object = object,
      type = type,
      alpha = alpha,
      std_y = std_y,
      std_x = std_x
    ),
    lm_process = lm_process,
    gamma = std$gamma,
    acov = std$acov,
    vcov = std$vcov,
    est = std$est
  )
  attributes(x = out)$std <- std_y && all(index)
  attributes(x = out)$mi <- FALSE
  class(x = out) <- c(
    "betadelta",
    class(x = out)
  )
  out
}
