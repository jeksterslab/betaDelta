## ---- test-betaDelta-diff-beta-delta-methods
lapply(
  X = 1,
  FUN = function(i,
                 text) {
    message(text)

    set.seed(42)

    if (!identical(Sys.getenv("NOT_CRAN"), "true") && !interactive()) {
      message("CRAN: tests skipped.")
      # nolint start
      return(invisible(NULL))
      # nolint end
    }

    testthat::test_that(
      paste(text, "methods"),
      {
        testthat::skip_on_cran()
        if (!exists("nas1982")) {
          try(
            data(
              "nas1982",
              package = "betaDelta"
            ),
            silent = TRUE
          )
        }
        df <- nas1982
        object <- lm(QUALITY ~ NARTIC + PCTGRT + PCTSUPP, data = df)
        mvn <- DiffBetaDelta(BetaDelta(object, type = "mvn"))
        print.diffbetadelta(mvn)
        summary.diffbetadelta(mvn)
        print.summary.diffbetadelta(summary.diffbetadelta(mvn))
        coef.diffbetadelta(mvn)
        vcov.diffbetadelta(mvn)
        confint.diffbetadelta(mvn)
        adf <- DiffBetaDelta(BetaDelta(object, type = "adf"))
        print.diffbetadelta(adf)
        summary.diffbetadelta(adf)
        print.summary.diffbetadelta(summary.diffbetadelta(adf))
        coef.diffbetadelta(adf)
        vcov.diffbetadelta(adf)
        confint.diffbetadelta(adf)
        testthat::expect_true(
          TRUE
        )
      }
    )
  },
  text = "test-betaDelta-diff-beta-delta-methods"
)
