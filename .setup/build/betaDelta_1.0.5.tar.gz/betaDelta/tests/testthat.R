library(testthat)
library(betaDelta)

test_check("betaDelta")
