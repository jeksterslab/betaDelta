# betaDelta 1.0.7

## Patch

* Minor edits to methods.

# betaDelta 1.0.6

## Patch

* Minor edits to tests.

# betaDelta 1.0.5

## Patch

* Minor documentation edits.

# betaDelta 1.0.4

## Patch

* Added the `Delta()` and `DeltaGeneric()` functions.

# betaDelta 1.0.3

## Patch

* Minor documentation edits.

# betaDelta 1.0.2

## Patch

* Added degrees of freedom to the table of results.

# betaDelta 1.0.1

## Patch

* Added the `DiffBetaDelta()` function.

# betaDelta 1.0.0

## Major

* And so it begins.
